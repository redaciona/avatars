const Mouth02 = `<svg width="306" height="306" viewBox="0 0 306 306" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M188.9 181.5C182.4 179.9 175.7 181.3 169.1 181.7C168.4 181.7 168.2 180.8 168.8 180.5C174.2 177.3 183.7 174.8 188.9 179.3C189.3 179.8 190.5 180.9 189.6 181.5C189.4 181.6 189.1 181.6 188.9 181.5Z" fill="black"/>
</svg>
`;
module.exports = Mouth02;