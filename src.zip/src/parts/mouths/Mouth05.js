const Mouth05 = `<svg width="306" height="306" viewBox="0 0 306 306" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M188.5 179.4C182.1 185.5 170 180.6 166.8 173.2C166.4 172.3 167.4 171.5 168.2 171.9C169.9 172.8 171.4 173.7 173 174.4C177.6 176.5 182.4 178.2 187.5 177.7C188.5 177.5 189.2 178.7 188.5 179.4Z" fill="black"/>
</svg>
`;
module.exports = Mouth05;