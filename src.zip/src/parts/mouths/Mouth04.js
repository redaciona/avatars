const Mouth04 = `<svg width="306" height="306" viewBox="0 0 306 306" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M186.2 179C186.3 180.6 185.1 183.4 182.9 185.4C171.6 178.5 166.5 182.1 166.5 182.1C162.5 176 163.4 167.7 173.1 174C179.8 178.4 184 179.1 186.2 179Z" fill="black"/>
<path d="M182.799 185.5C180.399 187.6 176.799 188.9 171.899 186.9C169.599 186 167.799 184.2 166.399 182.2C166.499 182.2 171.499 178.6 182.799 185.5Z" fill="white"/>
<path d="M188.1 178.7C188.1 178.7 183.9 181 173.1 174.1C160.2 165.8 162.8 183.2 171.9 186.9C181.4 190.8 186.3 182.3 186.2 179.1" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M166.5 182.2C166.5 182.2 171.6 178.6 182.9 185.5" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`;
module.exports = Mouth04;