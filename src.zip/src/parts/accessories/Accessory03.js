const Accessory03 = `<svg width="306" height="306" viewBox="0 0 306 306" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M201.9 158.1C201.9 158.1 203.1 164.9 211 168.3C213 169.1 215.1 167.8 215.1 165.6C215 165.6 202.4 158.9 201.9 158.1Z" fill="black"/>
<path d="M140.1 158.1C140.1 158.1 143.8 166.5 154.9 168.5C166 170.6 176.1 162.6 180.8 149.2C180.8 149.2 177 161.6 161.8 163.9C146.8 166.4 140.1 158.1 140.1 158.1Z" fill="black"/>
<path d="M183.001 139.4C182.701 153.7 171.201 165.2 157.301 165.2C143.401 165.2 132.301 153.7 132.301 139.4C132.401 125 143.901 113.2 158.001 113.2C172.101 113.2 183.401 125 183.001 139.4Z" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M196.7 136.1C198.3 123.2 206.7 113.1 216.6 113.1C227.3 113.1 235.5 124.9 234.9 139.3C234.3 153.6 225.3 165.1 214.8 165.1C210.9 165.1 207.4 163.6 204.5 160.9" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M132.6 136.6H118.4" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M183.1 136.6C183.1 136.6 195 132 196.5 136.6" stroke="black" stroke-width="3" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`;
module.exports = Accessory03;